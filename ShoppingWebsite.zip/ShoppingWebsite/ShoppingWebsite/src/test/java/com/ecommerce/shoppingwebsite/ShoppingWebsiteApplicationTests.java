package com.ecommerce.shoppingwebsite;

import org.junit.jupiter.api.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoppingWebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
