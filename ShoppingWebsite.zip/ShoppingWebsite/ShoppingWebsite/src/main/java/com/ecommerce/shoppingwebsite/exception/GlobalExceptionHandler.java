package com.ecommerce.shoppingwebsite.exception;

public class GlobalExceptionHandler {

}
