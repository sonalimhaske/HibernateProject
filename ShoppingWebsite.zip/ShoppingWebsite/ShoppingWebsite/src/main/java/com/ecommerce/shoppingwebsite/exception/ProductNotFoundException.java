package com.ecommerce.shoppingwebsite.exception;

public class ProductNotFoundException {

}
